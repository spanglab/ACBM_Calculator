# ACBM Cost Calculator

This repository houses the Animal Cell Based Meat cost calculator. This repository only houses the code, which will be set to public once the manuscript is published. Please email jsfell@ucdavis.edu if you would like to review the code.

In the meantime you can check it out on Heroku! https://acbm-cost-calculator.herokuapp.com/
